package conmanagementweb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import conmanagementDAO.EmployeeDAO;
import conmanagementmodule.Employee;






@WebServlet("/empservlet")
public class Employeeservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Employeeservlet() {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
	}

	
	public void destroy() {
		System.out.println("destroy");
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service..!");
		String Firstname=request.getParameter("firstname");
		String Lastname=request.getParameter("lastname");
		String Username=request.getParameter("username");
		String Password=request.getParameter("password");
		String Address=request.getParameter("address");
		String contact=request.getParameter("contact");
		System.out.println("username"+Username);
		
		PrintWriter out=response.getWriter();
		out.print(Firstname);		
		Employee employee=new Employee();
		employee.setFirstname(Firstname);
		employee.setLastname(Lastname);
		employee.setUsername(Username);
		employee.setPassword(Password);
		employee.setAddress(Address);
		employee.setContact(contact);
		
		
		int status=EmployeeDAO.saveData(employee);
		if(status>0) {
			request.getRequestDispatcher("index.html").include(request,response);
			
			out.println("Record Insert succesfully...!");
		}
		else {
			System.out.println("record not success");
		}
	}

}
