package conmanagementweb;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import conmanagementmodule.AdminLogin;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/Logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession sesion=request.getSession();
		AdminLogin admin=(AdminLogin)sesion.getAttribute("admin");
		if(admin!=null) {
		sesion.invalidate();
		request.getRequestDispatcher("adminLogin.html").include(request, response);;
		}
		else {
			sesion.invalidate();
		request.getRequestDispatcher("empLogin.html").include(request, response);;
		}
		out.print("you are successfully loggedout");
		
	}

}
