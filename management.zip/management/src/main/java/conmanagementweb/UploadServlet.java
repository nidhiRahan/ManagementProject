package conmanagementweb;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;


@WebServlet("/upload")
public class UploadServlet
extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String filePath;
       private int maxFileSize=50*1024;
       private int  maxMemSize=4*1024;
       private boolean ismultipart;
       private File file;
   
       public UploadServlet() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	ismultipart=ServletFileUpload.isMultipartContent(request);
	System.out.println("isMultipart:"+ismultipart);
	if (!ismultipart) {
		System.out.println("not upload file");
	}
	DiskFileItemFactory factory=new DiskFileItemFactory();
	factory.setSizeThreshold( maxMemSize);
	factory.setRepository(new File("c://temp"));
	
	System.out.println("factory:"+factory);
	
	ServletFileUpload fileUpload=new ServletFileUpload(factory);
	fileUpload.setSizeMax(maxFileSize);
	System.out.println("file upload"+fileUpload);
	try {
	List fileItems= fileUpload.parseRequest(request);
	Iterator i=fileItems.iterator();
	System.out.println("i:"+i);
	
	while(i.hasNext() )
	{
		FileItem fi=(FileItem)i.next();
		
		if()
	}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	}


	
		
	}


