package conmanagementweb;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import conmanagementDAO.EmployeeDAO;
import conmanagementmodule.AdminLogin;
import conmanagementmodule.EmployeeLogin;


@WebServlet("/adminLogin")
public class AdminLoginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   private EmployeeDAO employeeDAO;
    public AdminLoginservlet() {
        super();
       
    }
    public void init(ServletConfig config) throws ServletException {
		employeeDAO=new EmployeeDAO();
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username =request.getParameter("username");
		String password=request.getParameter("password");
		
		AdminLogin adminLogin= new AdminLogin();
		adminLogin.setUsername(username);
		adminLogin.setPassword(password);
		
		AdminLogin admin =employeeDAO.adminLogin(adminLogin);
		if(admin!=null){
			//session
			HttpSession session= request.getSession();
			session.setAttribute("admin",admin);
			response.sendRedirect("employeeList.jsp");
		}
		else {
			response.sendRedirect("not");
			}
	}

}
