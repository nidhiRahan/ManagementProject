

package conmanagementDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

import conmanagementmodule.AdminLogin;
//import java.sql.SQLException;
import conmanagementmodule.Employee;
import conmanagementmodule.EmployeeLogin;

public class EmployeeDAO {
	 
		// private static final List<mployee> List = null;

		public static Connection getConnection(){
			Connection con = null;
			 try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						System.out.println("driver ragister");
					    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/management?enabledTLSProtocolsTLSv1.2", "root", "nidhi@123");
					    System.out.println("DB connection");
					} catch (Exception e) {
						
						e.printStackTrace();
					}
					return con;
}
		 public static int saveData(Employee employee) {
			 int status=0;
			 System.out.println("savedata method");
			 Connection connection=EmployeeDAO.getConnection();
			System.out.println("con:"+connection);
			try {
				
				PreparedStatement ps=connection.prepareStatement("insert into employee(firstname,lastname,username,password,address,contact) values(?,?,?,?,?,?)");
			ps.setString(1,employee.getFirstname());
			ps.setString(2,employee.getLastname());
			ps.setString(3,employee.getUsername());
			ps.setString(4,employee.getPassword());
			ps.setString(5,employee.getAddress());
			ps.setString(6,employee.getContact());
			
			status=ps.executeUpdate();
			System.out.println("status"+status);
			
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			return status;
		 }
		
		 
		 //login validate 
		 public static boolean  loginValidate(EmployeeLogin employeeLogin)  {
			boolean status= false;
			System.out.println("savedata method1");
			 Connection connection=EmployeeDAO.getConnection();
			 System.out.println("connection:"+connection);
			 try {
				PreparedStatement ps =connection.prepareStatement("select *from employee where username=? and password=?");
			 
				 
	        ps.setString(1, employeeLogin.getUsername());
	        ps.setString(2, employeeLogin.getPassword());
	      
	        ResultSet rs=  ps.executeQuery();
			
			System.out.println("Resultset:" +rs);
			//System.out.println("next method=" +  rs.next());
			
	         status=  rs.next(); 
			//System.out.println(status);
			
			 } catch(SQLException e) {
				
				System.out.println(e);
			}
			 return status;
		 }
		 
		 //adminLogin
		 //login employee validate
		 public  AdminLogin adminLogin(AdminLogin adminLogin) {
			 Connection connection=EmployeeDAO.getConnection();
			AdminLogin adminLogin2  =null;
			 
			 try {
				PreparedStatement ps =connection.prepareStatement(" select *from admin where email=? and password=?");
			ps.setString(1,adminLogin.getUsername());
	        ps.setString(2,adminLogin.getPassword());
	        ResultSet rs=  ps.executeQuery();
			
			//System.out.println("Resultset:" +rs);
			//System.out.println("next method=" +  rs.next());
			//status= rs.next();
			//System.out.println(status);
			
			if(rs.next()) {
				adminLogin2 =new AdminLogin();
				adminLogin2.setUsername(rs.getString("email"));
				adminLogin2.setPassword(rs.getString("password"));
			}
			
			 } catch (Exception e) {
				 //System.out.println(e);
				 e.printStackTrace();
			}
			 return adminLogin2;
		 }
		 
		//get All list of Employee
		 public static List<Employee> getList() {
			 Connection connection = EmployeeDAO.getConnection();
			 java.util.List<Employee> list =new ArrayList<Employee>();
			 try {
				 PreparedStatement ps=connection.prepareStatement("select *from employee");
				 ResultSet rs=ps.executeQuery();
				 while(rs.next()) {
					 
					 Employee employee=new Employee();
					 employee.setId(rs.getInt("Id"));
					 employee.setFirstname(rs.getString("firstname"));
					 employee.setLastname(rs.getString("lastname"));
					 employee.setUsername(rs.getString("username"));
					 employee.setPassword(rs.getString("password"));
					 employee.setAddress(rs.getString("address"));
					 employee.setContact(rs.getString("contact"));
					 System.out.println(rs.getString("firstname"));
					 list.add(employee);
				 }
			 }
			 catch(Exception e){
				 e.printStackTrace();
				 System.out.println(e);
				 
			 }
			 return list;
		 }
		 //get employee by id
		 public static Employee getEmployeeById(int id) {
			 Employee employee=null;
			  Connection connection=EmployeeDAO.getConnection();
			  try {
				  
				 PreparedStatement ps=connection.prepareStatement("select *from employee where id=?");
			     ps.setInt(1,id);
				 ResultSet rs = ps.executeQuery();
			employee=new Employee();
			rs.next();
			employee.setFirstname(rs.getString("firstname"));
			employee.setLastname(rs.getString("lastname"));
			employee.setUsername(rs.getString("Username"));
			employee.setPassword(rs.getString("password"));
			employee.setAddress(rs.getString("address"));
			employee.setContact(rs.getString("contact"));
			  }
			  catch(Exception e){
				  e.printStackTrace();
			  }
			  return employee;
		 }
		//update Employee
			public static int updateEmployee(Employee employee,int id) {
				Connection connection= EmployeeDAO.getConnection();
				int status=0;
				try {
					
				PreparedStatement ps=connection.prepareStatement("update employee set firstname=?,lastname=?, username=?, password=?,address=?, contact=?  where id=?");
				ps.setString(1, employee.getFirstname());
				ps.setString(2,employee.getLastname());
				ps.setString(3, employee.getUsername());
				ps.setString(4, employee.getPassword());
				ps.setString(5, employee.getAddress());
				ps.setString(6, employee.getContact());
				
				ps.setInt(7 , id);
				status =ps.executeUpdate();
				System.out.println(status);
				} 
				catch(Exception e){
					e.printStackTrace();
				}
				return status;
			}
		//	delete employee by id
			public static int deleteEmployeeById(int id) {
				int status=0;
			Connection connection= EmployeeDAO.getConnection();
				
				try {
					PreparedStatement ps=connection.prepareStatement("delete from employee where id=?");
				ps.setInt(1,id);
				 status =ps.executeUpdate();
				System.out.println(status);
				}
				catch(Exception e){
					e.printStackTrace();
			
			}
				return status;
          }

		 
}
		
