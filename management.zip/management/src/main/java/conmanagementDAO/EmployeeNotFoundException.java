/**
 * 
 */
package conmanagementDAO;

/**
 * @author rahan
 *
 */
public class EmployeeNotFoundException extends Exception {

}
